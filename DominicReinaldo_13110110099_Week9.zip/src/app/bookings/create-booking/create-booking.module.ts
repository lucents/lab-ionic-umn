import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { IonicModule } from '@ionic/angular';
import { RouterModule, Routes } from '@angular/router';
// import { CreateBookingPage} from './create-booking.component;

// const routes: Routes = [
//   {
//     path: '',
//     component: CreateBookingPage
//   }
// ];

@NgModule({
  declarations: [],
  imports: [
    CommonModule,
    FormsModule,
    IonicModule
  ]
})


export class CreateBookingModule { }
